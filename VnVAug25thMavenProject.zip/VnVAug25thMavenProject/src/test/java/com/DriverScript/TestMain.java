package com.DriverScript;

import java.io.*;
import java.util.Properties;

import com.TestLibrary.MobilePurchase;
import com.Utilities.ExcelOperations;

public class TestMain 
{
	static File f;
	static FileInputStream fis;
	static Properties prop;
	static String PropPath ="F:\\Automation\\Training\\MP_TDD\\src\\com\\Config\\BasicInfo.properties";
	static ExcelOperations eo = new ExcelOperations();
	static MobilePurchase mp = new MobilePurchase();
	public static void main(String[] args) throws Exception 
	{
		//Get the Properties file open it
			f = new File(PropPath);
			fis = new FileInputStream(f);
			
			prop = new Properties();			
			prop.load(fis);			
			//System.out.println(" Base URL ::" +prop.getProperty("BaseUrl"));
			
		//Open an input excel sheet in read mode
				eo.setExcelFile(prop.getProperty("InputXLSheetPath"), "Nokia");
				
				System.out.println(" The number of sheets are :: "+eo.getSheetCount());
				int NoOfRows = eo.getRowCount("Nokia");
				System.out.println(" The number of rows are :: "+NoOfRows);
				
				for(int i=1;i<NoOfRows;i++)
				{
					// read the data from respective cell					
						String TCName = eo.getCellData(i, 1, "Nokia");				
					String ModelNumber = eo.getCellData(i, 3, "Nokia");
					String Accessory = eo.getCellData(i, 4, "Nokia");
					double Discount = eo.getCellDataNumeric(i, 5, "Nokia");
					String Paymentype = eo.getCellData(i, 6, "Nokia");
					
					System.out.println(" *************** Start executing the "+TCName+" test case ******************");
					
					System.out.println("           #### Test Data ######           ");
						System.out.println("Model Number :: "+ModelNumber);
						System.out.println("Accessory  :: "+Accessory);
						System.out.println("Discount :: "+Discount);
						System.out.println("Payment Type:: "+Paymentype);
					System.out.println("           #### Test Data ######           ");
					
					if(TCName.equalsIgnoreCase("Mobile Purchase"))
						mp.Purchase(ModelNumber);
					else if(TCName.equalsIgnoreCase("Mobile Purchase with accessories"))
						mp.Purchase(ModelNumber, Accessory);
					
					else if(TCName.equalsIgnoreCase("Mobile Purchase with accessories and discount"))
						mp.Purchase(ModelNumber, Accessory, Discount);
					
					else if(TCName.equalsIgnoreCase("Mobile Purchase with discount"))
						mp.Purchase(ModelNumber, Discount);				
					
					
					System.out.println(" *************** Completed executing the "+TCName+" test case ******************");
				}
				
						

	}

}
