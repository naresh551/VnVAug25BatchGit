package com.ObjectRespository;

public class SamsungMobileOR extends NokiaMobileOR
{
	
	
}
