package com.ObjectRespository;

public class NokiaMobileOR 
{
	String SearchTxtbox_id="twotabsearchtextbo";
	String SearchIcon_id ="nav-search-submit-button";
	

}
