package com.TestLibrary;

public class MobilePurchase 
{
	public void Purchase(String ModelNo)
	{
		System.out.println(" Purchase a mobile of model :: "+ModelNo);
	}
	
	public void Purchase(String ModelNo,double discount)
	{
		System.out.println(" Purchase a mobile of model :: "+ModelNo+" and with "+discount+"% discount");
	}
	
	
	public void Purchase(String ModelNo, String Accessories)
	{
		System.out.println(" Purchase a mobile of model :: "+ModelNo+" and with Accessories ::"+Accessories);
	}
	
	
	public void Purchase(String ModelNo, String Accessories,double discount)
	{
		System.out.println(" Purchase a mobile of model :: "+ModelNo+" and with Accessories ::"+Accessories+" and with "+discount+"% discount");
	}

}
